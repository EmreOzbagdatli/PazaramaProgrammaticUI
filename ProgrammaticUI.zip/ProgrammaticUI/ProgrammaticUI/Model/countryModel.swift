//
//  countryModel.swift
//  ProgrammaticUI
//
//  Created by Emre Özbağdatlı on 19.10.2023.
//

import Foundation

struct CountryModel {

    var country: String
    var countryImage: String

    init(country: String, countryImage: String) {
        self.country = country
        self.countryImage = countryImage
    }

}

let countryImage1 = CountryModel(country: "america", countryImage: "america")
let countryImage2 = CountryModel(country: "italy", countryImage: "italy")
let countryImage3 = CountryModel(country: "india", countryImage: "india")
let countryImage4 = CountryModel(country: "korea", countryImage: "korea")
let countryImage5 = CountryModel(country: "china", countryImage: "china")
let countryImage: [CountryModel] = [countryImage1, countryImage2, countryImage3, countryImage4, countryImage5]
